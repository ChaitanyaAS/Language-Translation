from flask import Flask, request, render_template
from transformers import MarianMTModel, MarianTokenizer

app = Flask(__name__)

# Load the translation model and tokenizer
model_name = 'Helsinki-NLP/opus-mt-en-de'  # Change this for different languages
tokenizer = MarianTokenizer.from_pretrained(model_name)
model = MarianMTModel.from_pretrained(model_name)

def translate_text(text, target_language):
    try:
        # Tokenize the input text
        inputs = tokenizer(text, return_tensors="pt", padding=True)
        # Perform the translation
        translated_tokens = model.generate(**inputs)
        # Decode the translated tokens
        translation = tokenizer.decode(translated_tokens[0], skip_special_tokens=True)
        return translation
    except Exception as e:
        return f"An error occurred: {str(e)}"

@app.route('/', methods=['GET', 'POST'])
def home():
    translation = ""
    if request.method == 'POST':
        input_text = request.form.get('input_text', '')
        target_language = request.form.get('target_language', '')

        if not input_text:
            translation = "Please enter text to translate."
        elif not target_language:
            translation = "Please select a target language."
        else:
            # Change the model based on the target language if necessary
            translation = translate_text(input_text, target_language)

    return render_template('index.html', translation=translation)

if __name__ == "__main__":
    app.run(debug=True)
